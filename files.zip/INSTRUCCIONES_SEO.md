# ✅ Guía SEO — Killa Creaciones
## Qué subir a tu servidor

Sube estos 3 archivos a la RAÍZ de tu hosting (donde está tu index.html actual):

- index.html     ← reemplaza tu index.html actual
- sitemap.xml    ← archivo nuevo
- robots.txt     ← archivo nuevo

---

## Pasos obligatorios DESPUÉS de subir los archivos

### 1. Registrarte en Google Search Console
👉 https://search.google.com/search-console

- Clic en "Agregar propiedad"
- Escribe: killaluzcreaciones.pe
- Elige verificación por "Etiqueta HTML" o por DNS
- Sigue las instrucciones para verificar que eres el dueño

### 2. Enviar tu Sitemap
Dentro de Search Console:
- Menú izquierdo → "Sitemaps"
- Pega: https://killaluzcreaciones.pe/sitemap.xml
- Clic en "Enviar"

### 3. Solicitar indexación de tu página principal
- Menú izquierdo → "Inspección de URL"
- Escribe tu URL: https://killaluzcreaciones.pe/
- Clic en "Solicitar indexación"

### 4. Crear una imagen para redes sociales (og-image)
Crea una imagen de 1200x630 píxeles con el logo de Killa Creaciones
y súbela a tu servidor como: /og-image.jpg
Esta imagen aparece cuando compartes el link en WhatsApp, Facebook, etc.

---

## Mejoras adicionales recomendadas (opcional)

- Agregar Google Analytics para ver cuántas visitas recibes
- Crear páginas separadas para cada categoría (mejor para SEO)
- Reemplazar emojis de productos por fotos reales con texto alt
- Registrar tu negocio en Google My Business si tienes local físico

---

## ¿Cuánto tiempo tarda Google en indexarte?
- Después de enviar el sitemap: 3 a 14 días normalmente
- Puedes acelerar el proceso compartiendo tu URL en redes sociales
  (eso genera backlinks que ayudan a Google a encontrarte más rápido)
